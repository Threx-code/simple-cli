<?php
/**
 * @author Oluwatosin Amokeodo <oluwatosin.amokeodo@gmail.com>
 * @package CRUD API
 * * @license MIT http://opensource.org/licenses/MIT
 * @since Version 1.0
 */

namespace App\Command\CLI;

use App\Command\Helpers\CommandHelper;

class HelpCommand extends CommandHelper
{
    public function handle()
    {
    }
}
