<nav class="navbar navbar-expand-md navbar-dark bg-dark fixed-top nav_container">
    <div class="navbar-collapse nav_content">

        <a class="nav-item nav-link navlink active" href="#tab-1">
            Simple Properties
        </a>
    </div>
</nav>
<style>
	.nav-link{float: left;color: #eee;}
</style>
